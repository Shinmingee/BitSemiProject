package Test10;


import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;


class ChatThread extends Thread {
	Socket sock;
	InputStream input;
	OutputStream output;
	PrintWriter pw;
	BufferedReader br;
	
	ChatThread(Socket sock) {
		this.sock = sock;
		try {
			input = sock.getInputStream();
			output = sock.getOutputStream();
			pw = new PrintWriter(new OutputStreamWriter(sock.getOutputStream()));
			br = new BufferedReader(new InputStreamReader(sock.getInputStream()));
		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
		}
	}// ������
	
	public void run() {/////////////////////////////////////////////////////////////////////////////////////////////

		// �޴� �����ִ� Ŭ����
		ShowMenu showMenu = new ShowMenu(pw);
		// ���ð� �޴� Ŭ����
		SelectMenu selectMenu = new SelectMenu(br, pw);
		// ���� ��ȸ ����ϴ� Ŭ����
		SearchQuery searchQuery = new SearchQuery(pw, selectMenu);

		try {
			String line;
			do {
				selectMenu.mainSelect();
				if(selectMenu.selectNum.equals("1")) {
					selectMenu.oilchoiceSelect();
					searchQuery.searchMIN();
				}else if (selectMenu.selectNum.equals("2")) {
					selectMenu.brandchoiceSelect();
					searchQuery.searchBrand();
				}else {
					pw.println("�߸� �Է��ϼ̽��ϴ�. �ٽ� �������ּ���.");
					pw.flush();
					showMenu.choiceMenu();
				}

			} while ((line = br.readLine()) != null);// while end

		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
		}

	}// run()

}

public class Server {
	public static void main(String[] args) {

		try {
			ServerSocket server = new ServerSocket(10001);
			System.out.println("������ ��ٸ��ϴ�.");

			while (true) {
				Socket sock = server.accept();
				ChatThread thread = new ChatThread(sock);

//				new Thread(thread).start();//////////////////////////////////// Ŀ�ؼ� Ǯ  �ν��Ͻ� �������� ����?
				thread.start();////////////////////////////////////

			} // while end

		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
		}

	}// main
}// Server